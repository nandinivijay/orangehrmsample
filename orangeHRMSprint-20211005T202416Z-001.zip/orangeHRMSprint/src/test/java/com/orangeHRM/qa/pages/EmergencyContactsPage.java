package com.orangeHRM.qa.pages;

import org.openqa.selenium.WebDriver;

public class EmergencyContactsPage {
	WebDriver driver;

	public EmergencyContactsPage(WebDriver driver) {
		
		this.driver = driver;
	}

	public boolean getcurrentUrl() {
		
		return driver.getCurrentUrl().contains("viewEmergencyContacts");
	}
}
