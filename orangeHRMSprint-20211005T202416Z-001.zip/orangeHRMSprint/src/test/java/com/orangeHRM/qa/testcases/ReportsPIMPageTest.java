package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.ReportsPIMPage;


public class ReportsPIMPageTest extends PIMPageTest{
	
	ReportsPIMPage reportsPIMPage;
	
	@BeforeClass
	public void verifyReportsPIMPageNavigation()
	{
		reportsPIMPage = pimPage.navigatingToReports();
		Assert.assertTrue(reportsPIMPage.getcurrentUrl());
		System.out.println("Clicked Reports PIM and asserted URL");
	}
	
	@Test(priority = 2)
	public void reportsPIMTesting()
	{
		System.out.println("Reports PIM clicked");
	}

}
