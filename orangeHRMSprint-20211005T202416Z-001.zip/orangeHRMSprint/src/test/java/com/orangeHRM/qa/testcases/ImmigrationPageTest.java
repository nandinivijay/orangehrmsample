package com.orangeHRM.qa.testcases;

import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import com.orangeHRM.qa.pages.ImmigrationPage;
import com.orangeHRM.qa.util.ActionsUtil;

public class ImmigrationPageTest extends MyInfoPageTest {
	ImmigrationPage immigrationPage;
	WebElement element;

	@BeforeClass
	public void verifyImmigrationPageNavigation() {

		immigrationPage = myInfoPage.navigatingToImmigration();
		System.out.println("Clicked Immigrations and url is validated");
	}

	@Test /* (priority=3) */
	public void validateImmigationsButton_bgcolor() {
		try {

			
			// details button bg-color- grey
			element = myInfoPage.getImmigration_XPath();
			ActionsUtil.MouseHoover(element, driver);
			Assert.assertTrue(myInfoPage.getColor_Sidenav(element).contains(myInfoPage.SIDENAV_CLICKEDCOLOR),
					"*********Buttton clicked color mis match*************");
			System.out.println("Immigration button bg-color is validated after clicking---grey");
			
			
		} catch (AssertionError ae) {
			System.out.println("In Immigration Testing--validateImmigationsButton_bgcolor :" + ae.getMessage());
		} catch (WebDriverException we) {
			System.out.println("In Immigration--validateImmigationsButton_bgcolor :" + we.getMessage());
		}

	}
}
