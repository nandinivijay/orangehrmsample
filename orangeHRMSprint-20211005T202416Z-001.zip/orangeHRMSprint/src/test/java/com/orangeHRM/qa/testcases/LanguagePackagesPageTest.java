package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.LanguagePackagesPage;

public class LanguagePackagesPageTest extends ConfigurationAdminPageTest{

	LanguagePackagesPage languagePackagesPage;
	@BeforeClass
	public void verifyLanguagePackagesPageNavigation()
	{
		languagePackagesPage = configurationAdminPage.navigatingToLanguagePackages();
		Assert.assertTrue(languagePackagesPage.getcurrentUrl());
		System.out.println("Clicked Language Packages and asserted URL");
	}
	
	@Test(priority = 4)
	public void languagePackagesTesting()
	{
		System.out.println("Language Packages clicked");
	}
}
