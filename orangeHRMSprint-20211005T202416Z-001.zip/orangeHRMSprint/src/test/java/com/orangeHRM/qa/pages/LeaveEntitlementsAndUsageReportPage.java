package com.orangeHRM.qa.pages;

import org.openqa.selenium.WebDriver;

public class LeaveEntitlementsAndUsageReportPage {

	WebDriver driver;
	public LeaveEntitlementsAndUsageReportPage(WebDriver driver) {
		
		this.driver = driver;
	}
	
	public boolean getcurrentUrl()
	{
		return driver.getCurrentUrl().contains("LeaveBalanceReport");
	}

	
}
