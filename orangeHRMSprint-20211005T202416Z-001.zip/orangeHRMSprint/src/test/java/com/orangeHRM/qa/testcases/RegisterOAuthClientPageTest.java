package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.RegisterOAuthClientPage;


public class RegisterOAuthClientPageTest extends ConfigurationAdminPageTest{

	RegisterOAuthClientPage registerOAuthClientPage;
	@BeforeClass
	public void verifyRegisterOAuthClientPageNavigation()
	{
		registerOAuthClientPage = configurationAdminPage.navigatingToRegisterOAuthClient();
		Assert.assertTrue(registerOAuthClientPage.getcurrentUrl());
		System.out.println("Clicked Register O Auth Client and asserted URL");
	}
	
	@Test(priority = 4)
	public void registerOAuthClientTesting()
	{
		System.out.println("Register O Auth Client clicked");
	}
}
