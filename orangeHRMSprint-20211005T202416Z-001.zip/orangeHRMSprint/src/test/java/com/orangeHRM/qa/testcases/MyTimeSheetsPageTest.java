package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.MyTimeSheetsPage;

public class MyTimeSheetsPageTest extends TimeSheetsPageTest{

	MyTimeSheetsPage myTimeSheetsPage;
	@BeforeClass
	public void verifyMyTimeSheetsPageNavigation()
	{
		myTimeSheetsPage = timeSheetsPage.navigatingToMyTimeSheets();
		Assert.assertTrue(myTimeSheetsPage.getcurrentUrl());
		System.out.println("Clicked MyTimeSheets and asserted URL");
	}
	
	@Test(priority = 4)
	public void myTimeSheetsTesting()
	{
		System.out.println("MyTimeSheets clicked");
	}
}
