package com.orangeHRM.qa.pages;

import org.openqa.selenium.WebDriver;

public class StructurePage {

	WebDriver driver;

	public StructurePage(WebDriver driver) {
		
		this.driver = driver;
	}
	
	public boolean getcurrentUrl()
	{
		return driver.getCurrentUrl().contains("Structure");
	}

}
