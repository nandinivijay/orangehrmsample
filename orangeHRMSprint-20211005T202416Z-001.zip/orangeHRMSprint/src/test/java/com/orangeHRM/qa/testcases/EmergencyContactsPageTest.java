package com.orangeHRM.qa.testcases;

import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import com.orangeHRM.qa.pages.EmergencyContactsPage;
import com.orangeHRM.qa.util.ActionsUtil;

public class EmergencyContactsPageTest extends MyInfoPageTest{
	EmergencyContactsPage emergencyContactsPage;
	WebElement element;

	@BeforeClass
	public void verifyEmergencyContactsPageNavigation() {

		emergencyContactsPage = myInfoPage.navigatingToEmergencyContacts();
		System.out.println("Clicked Emergency Contacts and url is validated");
	}

	@Test /* (priority=3) */
	public void validateEmergencyContactsButton_bgcolor() {
		try {

			
			// details button bg-color- grey
			element = myInfoPage.getEmergencyContacts_XPath();
			ActionsUtil.MouseHoover(element, driver);
			Assert.assertTrue(myInfoPage.getColor_Sidenav(element).contains(myInfoPage.SIDENAV_CLICKEDCOLOR),
					"*********Buttton clicked color mis match*************");
			System.out.println("Emergency contacts button bg-color is validated after clicking---grey");
		
		} catch (AssertionError ae) {
			System.out.println("In EmergencyContacts Testing--validateContactDetailsButton_bgcolor :" + ae.getMessage());
		} catch (WebDriverException we) {
			System.out.println("In EmergencyContactss--validateEmergencyContactsButton_bgcolor :" + we.getMessage());
		}

	}
}
