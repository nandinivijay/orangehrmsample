package com.orangeHRM.qa.testcases;

import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.Qualification_MyInfoPage;
import com.orangeHRM.qa.util.ActionsUtil;

public class Qualifiation_MyInfoPageTest extends MyInfoPageTest{
	Qualification_MyInfoPage qualifiation_MyInfoPage;
	WebElement element;

	@BeforeClass
	public void verifyQualifiation_MyInfoPageNavigation() {

		qualifiation_MyInfoPage = myInfoPage.navigatingToQualification_MyInfo();
		System.out.println("Clicked Qualifiation_MyInfoPage and url is validated");
	}

	@Test /* (priority=3) */
	public void validateQualifiation_MyInfoButton_bgcolor() {
		try {

			
			// details button bg-color- grey
			element = myInfoPage.getQualification_MyInfo_XPath();
			ActionsUtil.MouseHoover(element, driver);
			Assert.assertTrue(myInfoPage.getColor_Sidenav(element).contains(myInfoPage.SIDENAV_CLICKEDCOLOR),
					"*********Buttton clicked color mis match*************");
			System.out.println("qualifiation_MyInfoPage button bg-color is validated after clicking---grey");
			
			
		} catch (AssertionError ae) {
			System.out.println("In qualifiation_MyInfoPage Testing--validateQualifiation_MyInfoButton_bgcolor :" + ae.getMessage());
		} catch (WebDriverException we) {
			System.out.println("In qualifiation_MyInfoPage--validateQualifiation_MyInfoButton_bgcolor :" + we.getMessage());
		}

	}



}
