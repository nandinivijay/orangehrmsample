package com.orangeHRM.qa.pages;

import org.openqa.selenium.WebDriver;

public class SkillsPage {

	WebDriver driver;

	public SkillsPage(WebDriver driver) {
		
		this.driver = driver;
	}

	public boolean getcurrentUrl()
	{
		return driver.getCurrentUrl().contains("Skills");
	}
}
