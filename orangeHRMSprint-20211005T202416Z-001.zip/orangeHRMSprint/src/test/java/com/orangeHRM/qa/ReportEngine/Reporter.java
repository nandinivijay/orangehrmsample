package com.orangeHRM.qa.ReportEngine;

public class Reporter {

	public Reporter() {
		// TODO Auto-generated constructor stub
	}

}
