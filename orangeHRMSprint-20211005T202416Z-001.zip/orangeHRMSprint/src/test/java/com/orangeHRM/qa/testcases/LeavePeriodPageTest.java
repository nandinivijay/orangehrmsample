package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.LeavePeriodPage;

public class LeavePeriodPageTest extends ConfigureLeavePageTest{
	
	LeavePeriodPage leavePeriodPage;
	@BeforeClass
	public void verifyLeavePeriodPageNavigation()
	{
		leavePeriodPage = configureLeavePage.navigatingToLeavePeriod();
		Assert.assertTrue(leavePeriodPage.getcurrentUrl());
		System.out.println("Clicked Leave Period and asserted URL");
	}
	
	@Test(priority = 2)
	public void leavePeriodTesting()
	{
		System.out.println("Leave Period clicked");
	}

}
