package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.ProjectsPage;

public class ProjectsPageTest extends ProjectInfoPageTest{

	ProjectsPage projectsPage;
	@BeforeClass
	public void verifyProjectsPageNavigation()
	{
		projectsPage = projectInfoPage.navigatingToProjects();
		Assert.assertTrue(projectsPage.getcurrentUrl());
		System.out.println("Clicked Projects and asserted URL");
	}
	
	@Test(priority = 3)
	public void projectsTesting()
	{
		System.out.println("Projects clicked");
	}
	
}
