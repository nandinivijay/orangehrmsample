package com.orangeHRM.qa.pages;

import org.openqa.selenium.WebDriver;

public class SalaryPage {
	WebDriver driver;

	public SalaryPage(WebDriver driver) {
		
		this.driver = driver;
	}

	public boolean getcurrentUrl() {
		
		return driver.getCurrentUrl().contains("viewSalaryList");
	}
}
