package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.HolidaysPage;

public class HolidaysPageTest extends ConfigureLeavePageTest{
	
	HolidaysPage holidaysPage;
	@BeforeClass
	public void verifyHolidaysPageNavigation()
	{
		holidaysPage = configureLeavePage.navigatingToHolidays();
		Assert.assertTrue(holidaysPage.getcurrentUrl());
		System.out.println("Clicked Holidays and asserted URL");
	}
	
	@Test(priority = 4)
	public void holidaysTesting()
	{
		System.out.println("Holidays clicked");
	}

}
