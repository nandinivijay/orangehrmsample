package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.EmployeeTrackersPage;

public class EmployeeTrackersPageTest extends PerformancePageTest{

	EmployeeTrackersPage employeeTrackersPage;
	@BeforeClass
	public void verifyEmployeeTrackersPageNavigation()
	{
		employeeTrackersPage = performancePage.navigatingToEmployeeTrackers();
		Assert.assertTrue(employeeTrackersPage.getcurrentUrl());
		System.out.println("Clicked Employee Trackers and asserted URL");
	}
	
	@Test(priority = 2)
	public void employeeTrackersTesting()
	{
		System.out.println("Employee Trackers clicked");
	}
}
