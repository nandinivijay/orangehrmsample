package com.orangeHRM.qa.pages;

import org.openqa.selenium.WebDriver;

public class MyRecordsPage {

	WebDriver driver;

	public MyRecordsPage(WebDriver driver) {
		
		this.driver = driver;
	}
	
	public boolean getcurrentUrl()
	{
		return driver.getCurrentUrl().contains("MyAttendanceRecord");
	}

}
