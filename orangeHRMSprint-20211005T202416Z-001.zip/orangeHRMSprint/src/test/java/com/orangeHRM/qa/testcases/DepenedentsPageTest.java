package com.orangeHRM.qa.testcases;

import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.DependentsPage;
import com.orangeHRM.qa.util.ActionsUtil;

public class DepenedentsPageTest extends MyInfoPageTest{
	DependentsPage dependentsPage;
	WebElement element;

	@BeforeClass
	public void verifypersonalDetailsPageNavigation() {

		dependentsPage = myInfoPage.navigatingToDependents();
		System.out.println("Clicked Dependents and url is validated");
	}

	@Test /* (priority=3) */
	public void validateDependentsButton_bgcolor() {
		try {

			
			// details button bg-color- grey
			element = myInfoPage.getDependents_XPath();
			ActionsUtil.MouseHoover(element, driver);
			Assert.assertTrue(myInfoPage.getColor_Sidenav(element).contains(myInfoPage.SIDENAV_CLICKEDCOLOR),
					"*********Buttton clicked color mis match*************");
			System.out.println("Dependents button bg-color is validated after clicking---grey");
			
			
		} catch (AssertionError ae) {
			System.out.println("In Dependents Testing--validateDependentsButton_bgcolor :" + ae.getMessage());
		} catch (WebDriverException we) {
			System.out.println("In Dependents--validateDependentsButton_bgcolor :" + we.getMessage());
		}

	}
}
