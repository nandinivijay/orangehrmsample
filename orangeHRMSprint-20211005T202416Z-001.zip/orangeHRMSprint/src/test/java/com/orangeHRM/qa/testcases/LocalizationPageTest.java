package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.LocalizationPage;

public class LocalizationPageTest extends ConfigurationAdminPageTest{

	LocalizationPage localizationPage;
	@BeforeClass
	public void verifyLocalizationPageNavigation()
	{
		localizationPage = configurationAdminPage.navigatingToLocalization();
		Assert.assertTrue(localizationPage.getcurrentUrl());
		System.out.println("Clicked Localization and asserted URL");
	}
	
	@Test(priority = 4)
	public void localizationTesting()
	{
		System.out.println("Localization clicked");
	}
}
