package com.orangeHRM.qa.testcases;

import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.ReportToPage;
import com.orangeHRM.qa.util.ActionsUtil;

public class ReportToPageTest extends MyInfoPageTest{
	ReportToPage reportToPage;
	WebElement element;

	@BeforeClass
	public void verifyReportToPageNavigation() {

		reportToPage = myInfoPage.navigatingToReportTo();
		System.out.println("Clicked ReportToPage and url is validated");
	}

	@Test /* (priority=3) */
	public void validateReportToButton_bgcolor() {
		try {

			
			// details button bg-color- grey
			element = myInfoPage.getReportTo_XPath();
			ActionsUtil.MouseHoover(element, driver);
			Assert.assertTrue(myInfoPage.getColor_Sidenav(element).contains(myInfoPage.SIDENAV_CLICKEDCOLOR),
					"*********Buttton clicked color mis match*************");
			System.out.println("ReportToPage button bg-color is validated after clicking---grey");
			
			
		} catch (AssertionError ae) {
			System.out.println("In ReportToPage Testing--validateReportToButton_bgcolor :" + ae.getMessage());
		} catch (WebDriverException we) {
			System.out.println("In ReportToPage--validateReportToButton_bgcolor :" + we.getMessage());
		}

	}


}
