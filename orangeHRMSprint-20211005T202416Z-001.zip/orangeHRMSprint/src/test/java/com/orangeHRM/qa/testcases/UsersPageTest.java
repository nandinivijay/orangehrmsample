package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.UsersPage;

public class UsersPageTest extends UserManagementPageTest{

	UsersPage usersPage;
	@BeforeClass
	public void verifyUsersPageNavigation()
	{
		usersPage = userManagementPage.navigatingToUsers();
		Assert.assertTrue(usersPage.getcurrentUrl());
		System.out.println("Clicked Users and asserted URL");
	}
	
	@Test(priority = 4)
	public void usersTesting()
	{
		System.out.println("Users clicked");
	}
}
