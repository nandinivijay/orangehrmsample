package com.orangeHRM.qa.pages;

import org.openqa.selenium.WebDriver;

public class PunchInOutPage {

	WebDriver driver;

	public PunchInOutPage(WebDriver driver) {
		
		this.driver = driver;
	}

	public boolean getcurrentUrl()
	{
		return driver.getCurrentUrl().contains("punchIn");
	}
}
