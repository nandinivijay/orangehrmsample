package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.GeneralInformationPage;

public class GeneralInformationPageTest extends OrganizationPageTest{

	GeneralInformationPage generalInformationPage;
	@BeforeClass
	public void verifyGeneralInformationPageNavigation()
	{
		generalInformationPage = organizationPage.navigatingToGeneralInformation();
		Assert.assertTrue(generalInformationPage.getcurrentUrl());
		System.out.println("Clicked General Information and asserted URL");
	}
	
	@Test(priority = 4)
	public void generalInformationTesting()
	{
		System.out.println("General Information clicked");
	}
}
