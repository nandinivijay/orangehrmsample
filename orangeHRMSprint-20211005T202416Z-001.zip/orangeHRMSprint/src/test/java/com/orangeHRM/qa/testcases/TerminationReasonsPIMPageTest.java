package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.TerminationReasonsPIMPage;

public class TerminationReasonsPIMPageTest extends ConfigurationPIMPageTest{

	TerminationReasonsPIMPage terminationReasonsPIMPage;
	@BeforeClass
	public void verifyTerminationReasonsPIMPageNavigation()
	{
		terminationReasonsPIMPage = configurationPIMPage.navigatingToTerminationReasons();
		Assert.assertTrue(terminationReasonsPIMPage.getcurrentUrl());
		System.out.println("Clicked Termination Reasons PIM and asserted URL");
	}
	
	@Test(priority = 4)
	public void terminationReasonsPIMTesting()
	{
		System.out.println("Termination Reasons PIM clicked");
	}
}
