package com.orangeHRM.qa.pages;

import org.openqa.selenium.WebDriver;

public class TrackersPage {

	WebDriver driver;

	public TrackersPage(WebDriver driver) {
		
		this.driver = driver;
	}

	public boolean getcurrentUrl()
	{
		return driver.getCurrentUrl().contains("addPerformanceTracker");
		
	}
}
