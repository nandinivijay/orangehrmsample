package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.CustomersPage;

public class CustomersPageTest extends ProjectInfoPageTest{
	

	CustomersPage customersPage;
	@BeforeClass
	public void verifyCustomersPageNavigation()
	{
		customersPage = projectInfoPage.navigatingToCustomers();
		Assert.assertTrue(customersPage.getcurrentUrl());
		System.out.println("Clicked Customers and asserted URL");
	}
	
	@Test(priority = 4)
	public void customersTesting()
	{
		System.out.println("Customers clicked");
	}

}
