package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.MyLeaveEntitlementsAndUsageReportPage;

public class  MyLeaveEntitlementsAndUsageReportPageTest extends ReportsLeavePageTest{
	
	MyLeaveEntitlementsAndUsageReportPage myLeaveEntitlementsAndUsageReportPage;
	@BeforeClass
	public void verifyMyLeaveEntitlementsAndUsageReportPageNavigation()
	{
		myLeaveEntitlementsAndUsageReportPage = reportsLeavePage.navigatingToMyLeaveEntitlementsAndUsageReport();
		Assert.assertTrue(myLeaveEntitlementsAndUsageReportPage.getcurrentUrl());
		System.out.println("Clicked Leave Period and asserted URL");
	}
	
	@Test(priority = 4)
	public void myLeaveEntitlementsAndUsageReportTesting()
	{
		System.out.println("My Leave Entitlements And Usage Report clicked");
	}

}
