package com.orangeHRM.qa.pages;

import org.openqa.selenium.WebDriver;

public class WorkShiftsPage {

	WebDriver driver;

	public WorkShiftsPage(WebDriver driver) {
		
		this.driver = driver;
	}
	
	public boolean getcurrentUrl()
	{
		return driver.getCurrentUrl().contains("workShift");
	}

}
