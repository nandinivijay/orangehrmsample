package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.MyRecordsPage;

public class MyRecordsPageTest extends AttendancePageTest{

	MyRecordsPage myRecordsPage;
	@BeforeClass
	public void verifyMyRecordsPageNavigation()
	{
		myRecordsPage = attendancePage.navigatingToMyRecords();
		Assert.assertTrue(myRecordsPage.getcurrentUrl());
		System.out.println("My Records and asserted URL");
	}
	
	@Test(priority = 4)
	public void myRecordsTesting()
	{
		System.out.println("MyRecords clicked");
	}

}
