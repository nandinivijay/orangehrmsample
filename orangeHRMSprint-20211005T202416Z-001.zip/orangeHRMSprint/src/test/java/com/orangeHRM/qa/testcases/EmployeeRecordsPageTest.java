package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.EmployeeRecordsPage;

public class EmployeeRecordsPageTest extends AttendancePageTest{

	EmployeeRecordsPage employeeRecordsPage;
	@BeforeClass
	public void verifyEmployeeRecordsPageNavigation()
	{
		employeeRecordsPage = attendancePage.navigatingToEmployeeRecords();
		Assert.assertTrue(employeeRecordsPage.getcurrentUrl());
		System.out.println("Clicked Employee Records and asserted URL");
	}
	
	@Test(priority = 4)
	public void employeeRecordsTesting()
	{
		System.out.println("Employee Records clicked");
	}

}
