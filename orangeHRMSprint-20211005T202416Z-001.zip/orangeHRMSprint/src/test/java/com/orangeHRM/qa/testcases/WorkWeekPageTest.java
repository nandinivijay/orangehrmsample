package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.WorkWeekPage;

public class WorkWeekPageTest extends ConfigureLeavePageTest{
	
	WorkWeekPage workweekPage;
	@BeforeClass
	public void verifyWorkWeekPageNavigation()
	{
		workweekPage = configureLeavePage.navigatingToWorkWeek();
		Assert.assertTrue(workweekPage.getcurrentUrl());
		System.out.println("Clicked Work Week and asserted URL");
	}
	
	@Test(priority = 2)
	public void workWeekTesting()
	{
		System.out.println("Work Week clicked");
	}

}
