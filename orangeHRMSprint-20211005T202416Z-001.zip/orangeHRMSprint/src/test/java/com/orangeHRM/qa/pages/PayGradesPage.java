package com.orangeHRM.qa.pages;

import org.openqa.selenium.WebDriver;

public class PayGradesPage {

	WebDriver driver;

	public PayGradesPage(WebDriver driver) {
		
		this.driver = driver;
	}

	public boolean getcurrentUrl()
	{
		return driver.getCurrentUrl().contains("PayGrades");
	}
	
}
