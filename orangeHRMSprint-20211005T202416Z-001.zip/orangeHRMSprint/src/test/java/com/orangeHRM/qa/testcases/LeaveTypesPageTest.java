package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.LeaveTypesPage;

public class LeaveTypesPageTest extends ConfigureLeavePageTest{
	
	LeaveTypesPage leaveTypesPage;
	@BeforeClass
	public void verifyLeaveTypesPageNavigation()
	{
		leaveTypesPage = configureLeavePage.navigatingToLeaveTypes();
		Assert.assertTrue(leaveTypesPage.getcurrentUrl());
		System.out.println("Clicked Leave Types and asserted URL");
	}
	
	@Test(priority = 2)
	public void leaveTypesTesting()
	{
		System.out.println("Leave Types clicked");
	}

}
