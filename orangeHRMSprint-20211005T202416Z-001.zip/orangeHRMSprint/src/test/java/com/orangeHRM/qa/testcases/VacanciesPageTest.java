package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.VacanciesPage;

public class VacanciesPageTest extends RecruitmentPageTest{
	
	VacanciesPage vacanciesPage;
	@BeforeClass
	public void verifyVacanciesPageNavigation()
	{
		vacanciesPage = recruitmentPage.navigatingToVacancies();
		Assert.assertTrue(vacanciesPage.getcurrentUrl());
		System.out.println("Clicked Vacancies and asserted URL");
	}
	
	@Test(priority = 2)
	public void vacanciesTesting()
	{
		System.out.println("Vacancies clicked");
	}

}
