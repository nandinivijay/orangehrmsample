package com.orangeHRM.qa.pages;

import org.openqa.selenium.WebDriver;

public class LanguagePackagesPage {

	WebDriver driver;

	public LanguagePackagesPage(WebDriver driver) {
		
		this.driver = driver;
	}

	public boolean getcurrentUrl()
	{
		return driver.getCurrentUrl().contains("languagePackage");
	}
}
