package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.LeaveEntitlementsAndUsageReportPage;


public class LeaveEntitlementsAndUsageReportPageTest extends ReportsLeavePageTest {
	
	LeaveEntitlementsAndUsageReportPage leaveEntitlementsAndUsageReportPage;
	@BeforeClass
	public void verifyLeaveEntitlementsAndUsageReportPageNavigation()
	{
		leaveEntitlementsAndUsageReportPage = reportsLeavePage.navigatingToLeaveEntitlementsAndUsageReport_ID();
		Assert.assertTrue(leaveEntitlementsAndUsageReportPage.getcurrentUrl());
		System.out.println("Clicked Leave Period and asserted URL");
	}
	
	@Test(priority = 4)
	public void leaveEntitlementsAndUsageReportTesting()
	{
		System.out.println("Leave Entitlements And Usage Report clicked");
	}

}

