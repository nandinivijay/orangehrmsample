package com.orangeHRM.qa.testcases;

import org.openqa.selenium.WebDriverException;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.orangeHRM.qa.pages.EmployeeEntitlementsPage;
import com.orangeHRM.qa.testdata.ExcelReaderWithIndex;
import com.orangeHRM.qa.util.DropDownUtil;

public class EmployeeEntitlementTestPage extends EntitlementsPageTest{
	EmployeeEntitlementsPage employeeEntitlementsPage;
	@BeforeClass
	public void verifyEmployemployeeEntitlementsPageNavigation()
	{
		employeeEntitlementsPage= entitlementsPage.navigatingToEmployeeEntitlementsPage();
		
	}
	@Test(priority=3)
	public void setcontext(ITestContext context) {
	int	sheetnumber=2;
	context.setAttribute("index", sheetnumber);
	}

	
	
	@Test(dataProvider = "paramName" ,dataProviderClass=ExcelReaderWithIndex.class ,priority=4)

	public void verifyEmployeeEntitlementsTestPage(String empname) throws Exception
	{
					employeeEntitlementsPage=new EmployeeEntitlementsPage(driver);
	
			employeeEntitlementsPage.Employee().clear();
			try {
				Assert.assertTrue(employeeEntitlementsPage.Employee().getAttribute("value").contains(empname));
				System.out.println("page data in EmpName: " +employeeEntitlementsPage.Employee().getAttribute("value") + "---Data from file : "+ empname);
				}catch(AssertionError ae) {
					System.out.println("In assignLeaveTesting--empname :" + ae.getMessage());
				}
				catch(WebDriverException we) {
				System.out.println("In alp comments :" + we.getMessage());
				}

			employeeEntitlementsPage.Employee().sendKeys(empname);
			DropDownUtil.selectbyvalue(employeeEntitlementsPage.LeaveType(), "2");
			employeeEntitlementsPage.LeavePeriod();
			DropDownUtil.selectbytext(employeeEntitlementsPage.LeavePeriod(), "2021-01-01 - 2021-12-31");
			employeeEntitlementsPage.SearchButton().click();
			
		}
}