package com.orangeHRM.qa.testcases;


import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.ReportsLeavePage;
import com.orangeHRM.qa.util.ActionsUtil;

public class ReportsLeavePageTest extends LeavePageTest {

	ReportsLeavePage reportsLeavePage;
	@BeforeClass
	public void verifyReportsLeavePageNavigation()
	{
		reportsLeavePage = leavePage.navigatingToReportsLeave();
		System.out.println("Clicked Reports Leave ");
	}
	
	@Test(priority = 2)
	public void validatingReortsLeaveSubMenuDisplay()
	{
		ActionsUtil.MouseHoover(leavePage.getReportsLeave_id(), driver);
		Assert.assertTrue(reportsLeavePage.getLeaveEntitlementsAndUsageReport_id().isDisplayed());
		System.out.println("LeaveEntitlementsAndUsageReport Displayed");
		Assert.assertTrue(reportsLeavePage.getMyLeaveEntitlementsAndUsageReport_id().isDisplayed());
		System.out.println("MyLeaveEntitlementsAndUsageReport Displayed");
		
	}
	
	
	@Test(priority = 2)
	public void reportsLeaveTesting()
	{
		System.out.println("Reports Leave clicked");
	}
}
