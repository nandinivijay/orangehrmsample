package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.AddEmployeePIMPage;


public class AddEmployeePIMPageTest extends PIMPageTest{
	
	AddEmployeePIMPage addEmployeePIMPage;
	
	@BeforeClass
	public void verifyAddEmployeePIMPageNavigation()
	{
		addEmployeePIMPage = pimPage.navigatingToAddEmployee();
		Assert.assertTrue(addEmployeePIMPage.getcurrentUrl());
		System.out.println("Clicked Add Employee PIM and asserted URL");
	}
	
	@Test(priority = 2)
	public void addEmployeePIMTesting()
	{
		System.out.println("Add Employee PIM clicked");
	}

}
