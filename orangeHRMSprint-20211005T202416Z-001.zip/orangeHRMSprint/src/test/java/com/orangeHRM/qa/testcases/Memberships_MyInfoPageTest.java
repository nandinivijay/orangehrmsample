package com.orangeHRM.qa.testcases;

import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.Memberships_MyInfoPage;
import com.orangeHRM.qa.util.ActionsUtil;

public class Memberships_MyInfoPageTest extends MyInfoPageTest {
	Memberships_MyInfoPage memberships_MyInfoPage;
	WebElement element;

	@BeforeClass
	public void verifyMemberships_MyInfoPageNavigation() {

		memberships_MyInfoPage = myInfoPage.navigatingToMemberships_MyInfo();
		System.out.println("Clicked Memberships_MyInfoPage and url is validated");
	}

	@Test /* (priority=3) */
	public void validateMemberships_MyInfoButton_bgcolor() {
		try {

			
			// details button bg-color- grey
			element = myInfoPage.getMemberships_MyInfo_XPath();
			ActionsUtil.MouseHoover(element, driver);
			Assert.assertTrue(myInfoPage.getColor_Sidenav(element).contains(myInfoPage.SIDENAV_CLICKEDCOLOR),
					"*********Buttton clicked color mis match*************");
			System.out.println("Memberships_MyInfoPage button bg-color is validated after clicking---grey");
			
			
		} catch (AssertionError ae) {
			System.out.println("In Memberships_MyInfoPage Testing--validateMemberships_MyInfoButton_bgcolor :" + ae.getMessage());
		} catch (WebDriverException we) {
			System.out.println("In Memberships_MyInfoPage--validateMemberships_MyInfoButton_bgcolor :" + we.getMessage());
		}

	}



}
