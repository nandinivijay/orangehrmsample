package com.orangeHRM.qa.pages;

import org.openqa.selenium.WebDriver;

public class ContactDetailsPage {

	WebDriver driver;

	public ContactDetailsPage(WebDriver driver) {
		
		this.driver = driver;
	}

	public boolean getcurrentUrl() {
		
		return driver.getCurrentUrl().contains("contactDetails");
	}
	
}
