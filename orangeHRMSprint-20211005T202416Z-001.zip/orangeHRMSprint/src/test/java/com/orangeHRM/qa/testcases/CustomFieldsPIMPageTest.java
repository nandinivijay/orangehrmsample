package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.CustomFieldsPIMPage;


public class CustomFieldsPIMPageTest extends ConfigurationPIMPageTest{

	CustomFieldsPIMPage customFieldsPIMPage;
	@BeforeClass
	public void verifyCustomFieldsPIMPageNavigation()
	{
		customFieldsPIMPage = configurationPIMPage.navigatingToCustomFields();
		Assert.assertTrue(customFieldsPIMPage.getcurrentUrl());
		System.out.println("Clicked Custom Fields and asserted URL");
	}
	
	@Test(priority = 4)
	public void customFieldsPIMTesting()
	{
		System.out.println("Custom Fields PIM clicked");
	}
}
