package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.CandidatesPage;

public class CandidatesPageTest extends RecruitmentPageTest{
	
	CandidatesPage candidatesPage;
	@BeforeClass
	public void verifyCandidatesPageNavigation()
	{
		candidatesPage = recruitmentPage.navigatingToCandidates();
		Assert.assertTrue(candidatesPage.getcurrentUrl());
		System.out.println("Clicked Candidates and asserted URL");
	}
	
	@Test(priority = 2)
	public void candidatesTesting()
	{
		System.out.println("Candidates clicked");
	}
}
