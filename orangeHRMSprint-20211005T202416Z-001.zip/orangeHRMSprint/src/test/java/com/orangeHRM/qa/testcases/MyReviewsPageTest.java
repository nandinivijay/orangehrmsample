package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.MyReviewsPage;

public class MyReviewsPageTest extends ManageReviewsPageTest{

	MyReviewsPage myReviewsPage;
	@BeforeClass
	public void verifyMyReviewsPageNavigation()
	{
		myReviewsPage =manageReviewsPage.navigatingToMyReviews();
		Assert.assertTrue(myReviewsPage.getcurrentUrl());
		System.out.println("Clicked My Reviews and asserted URL");
	}
	
	@Test(priority = 3)
	public void myReviewsTesting()
	{
		System.out.println("My Reviews clicked");
	}
}
