package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.SkillsPage;


public class SkillsPageTest extends QualificationsPageTest{

	SkillsPage skillsPage;
	@BeforeClass
	public void verifySkillsPageNavigation()
	{
		skillsPage = qualificationsPage.navigatingToSkills();
		Assert.assertTrue(skillsPage.getcurrentUrl());
		System.out.println("Clicked Skills and asserted URL");
	}
	
	@Test(priority = 4)
	public void skillsTesting()
	{
		System.out.println("Skills clicked");
	}
}
