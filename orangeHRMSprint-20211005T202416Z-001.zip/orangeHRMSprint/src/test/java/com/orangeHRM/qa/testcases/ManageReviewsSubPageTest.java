package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.ManageReviewsSubPage;

public class ManageReviewsSubPageTest extends ManageReviewsPageTest{

	ManageReviewsSubPage manageReviewsSubPage;
	@BeforeClass
	public void verifyManageReviewsSubPageNavigation()
	{
		manageReviewsSubPage = manageReviewsPage.navigatingToManageReviewsSubModule();
		Assert.assertTrue(manageReviewsSubPage.getcurrentUrl());
		System.out.println("Clicked Manage Reviews Sub and asserted URL");
	}
	
	@Test(priority = 4)
	public void manageReviewsSubTesting()
	{
		System.out.println("Manage Reviews Sub clicked");
	}
}
