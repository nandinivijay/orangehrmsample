package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.PunchInOutPage;

public class PunchInOutPageTest extends AttendancePageTest{

	PunchInOutPage punchInOutPage;
	@BeforeClass
	public void verifyPunchInOutPageNavigation()
	{
		punchInOutPage = attendancePage.navigatingToPunchInOut();
		Assert.assertTrue(punchInOutPage.getcurrentUrl());
		System.out.println("Clicked PunchInOut and asserted URL");
	}
	
	@Test(priority = 4)
	public void punchInOutTesting()
	{
		System.out.println("PunchInOut clicked");
	}

}
