package com.orangeHRM.qa.pages;

import org.openqa.selenium.WebDriver;

public class Qualification_MyInfoPage {
	WebDriver driver;

	public Qualification_MyInfoPage(WebDriver driver) {
		
		this.driver = driver;
	}

	public boolean getcurrentUrl() {
		
		return driver.getCurrentUrl().contains("viewQualifications");
	}
}
