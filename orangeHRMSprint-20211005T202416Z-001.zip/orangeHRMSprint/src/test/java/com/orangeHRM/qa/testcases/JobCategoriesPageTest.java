package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.JobCategoriesPage;

public class JobCategoriesPageTest extends JobAdminPageTest{

	JobCategoriesPage jobCategoriesPage;
	@BeforeClass
	public void verifyJobCategoriesPageNavigation()
	{
		jobCategoriesPage = jobAdminPage.navigatingToJobCategories();
		Assert.assertTrue(jobCategoriesPage.getcurrentUrl());
		System.out.println("Clicked Job Categories and asserted URL");
	}
	
	@Test(priority = 2)
	public void jobCategoriesTesting()
	{
		System.out.println("Job Categories clicked");
	}
}
