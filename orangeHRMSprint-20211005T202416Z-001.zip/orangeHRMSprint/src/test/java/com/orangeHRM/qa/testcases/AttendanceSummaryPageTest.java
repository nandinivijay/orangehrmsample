package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.AttendanceSummaryPage;

public class AttendanceSummaryPageTest extends ReportsTimePageTest{

	AttendanceSummaryPage attendanceSummaryPage;
	@BeforeClass
	public void verifyAttendanceSummaryPageNavigation()
	{
		attendanceSummaryPage = reportsTimePage.navigatingToAttendanceSummary();
		Assert.assertTrue(attendanceSummaryPage.getcurrentUrl());
		System.out.println("Clicked Attendance Summary and asserted URL");
	}
	
	@Test(priority = 4)
	public void attendanceSummaryTesting()
	{
		System.out.println("Attendance Summary clicked");
	}
}
