package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.EmailSubscriptionsPage;

public class EmailSubscriptionsPageTest extends ConfigurationAdminPageTest{

	EmailSubscriptionsPage emailSubscriptionsPage;
	@BeforeClass
	public void verifyEmailSubscriptionsPageNavigation()
	{
		emailSubscriptionsPage = configurationAdminPage.navigatingToEmailSubscriptions();
		Assert.assertTrue(emailSubscriptionsPage.getcurrentUrl());
		System.out.println("Clicked Email Subscriptions and asserted URL");
	}
	
	@Test(priority = 4)
	public void emailSubscriptionsTesting()
	{
		System.out.println("Email Subscriptions clicked");
	}
}
