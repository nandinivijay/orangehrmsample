package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.OptionalFieldsPIMPage;

public class OptionalFieldsPIMPageTest extends ConfigurationPIMPageTest{

	OptionalFieldsPIMPage optionalFieldsPIMPage;
	@BeforeClass
	public void verifyOptionalFieldsPIMPageNavigation()
	{
		optionalFieldsPIMPage = configurationPIMPage.navigatingToOptionalFields();
		Assert.assertTrue(optionalFieldsPIMPage.getcurrentUrl());
		System.out.println("Clicked Optional Fields and asserted URL");
	}
	
	@Test(priority = 4)
	public void optionalFieldsPIMTesting()
	{
		System.out.println("Optional Fields PIM clicked");
	}
}
