package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.NationalitiesPage;

public class NationalitiesPageTest extends AdminPageTest{

	NationalitiesPage nationalitiesPage;
	@BeforeClass
	public void verifyNationalitiesPageNavigation()
	{
		nationalitiesPage = adminPage.navigatingToNationalities();
		Assert.assertTrue(nationalitiesPage.getcurrentUrl());
		System.out.println("Clicked Nationalities and asserted URL");
	}
	
	@Test(priority = 2)
	public void nationalitiesTesting()
	{
		System.out.println("Nationalities clicked");
	}
}
