package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.ApplyLeavePage;


public class ApplyLeavePageTest extends LeavePageTest{

	ApplyLeavePage applyLeavePage;
	@BeforeClass
	public void verifyApplyLeaveNavigationPageNavigation()
	{
		applyLeavePage = leavePage.navigatingToApply();
		Assert.assertTrue(applyLeavePage.getcurrentUrl());
		System.out.println("Clicked Apply Leave ,Navigated to Apply Leave Page and asserted URL");
	}
	
	@Test(priority = 2)
	public void applyLeaveTesting()
	{
		System.out.println("Apply Leave clicked");
	}
}
