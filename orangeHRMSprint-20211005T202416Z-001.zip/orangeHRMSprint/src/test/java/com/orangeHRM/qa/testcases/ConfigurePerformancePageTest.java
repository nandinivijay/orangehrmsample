package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.ConfigurePerformancePage;
import com.orangeHRM.qa.util.ActionsUtil;

public class ConfigurePerformancePageTest extends PerformancePageTest{

	ConfigurePerformancePage configurePerformancePage;
	@BeforeClass
	public void verifyConfigurePerformancePageNavigation()
	{
		configurePerformancePage = performancePage.navigatingToConfigurePerformance();
		System.out.println("Clicked Configure Performance");
	}
	
	@Test(priority = 2)
	public void validatingConfigurePerformanceSubMenuDisplay()
	{
		ActionsUtil.MouseHoover(performancePage.getConfigurePerformance_id(), driver);
		Assert.assertTrue(configurePerformancePage.getKPIs_id().isDisplayed());
		System.out.println("KPIs Displayed");
		Assert.assertTrue(configurePerformancePage.getTrackers_id().isDisplayed());
		System.out.println("Trackers Displayed");
	}
	@Test(priority = 3)
	public void configurePerformanceTesting()
	{
		System.out.println("Configure Performance clicked");
	}
}
