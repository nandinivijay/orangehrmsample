package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.JobTitlesPage;

public class JobTitlesPageTest extends JobAdminPageTest{

	JobTitlesPage jobTitlesPage;
	@BeforeClass
	public void verifyJobTitlesPageNavigation()
	{
		jobTitlesPage = jobAdminPage.navigatingToJobTitles();
		Assert.assertTrue(jobTitlesPage.getcurrentUrl());
		System.out.println("Clicked Job Titles and asserted URL");
	}
	
	@Test(priority = 4)
	public void jobTitlesTesting()
	{
		System.out.println("Job Titles clicked");
	}
}
