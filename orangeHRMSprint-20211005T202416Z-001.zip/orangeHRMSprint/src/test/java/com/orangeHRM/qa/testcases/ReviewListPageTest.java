package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.ReviewListPage;

public class ReviewListPageTest extends ManageReviewsPageTest{

	ReviewListPage reviewListPage;
	@BeforeClass
	public void verifyMyTrackersPageNavigation()
	{
		reviewListPage = manageReviewsPage.navigatingToReviewList();
		Assert.assertTrue(reviewListPage.getcurrentUrl());
		System.out.println("Clicked Review List and asserted URL");
	}
	
	@Test(priority = 4)
	public void reviewListTesting()
	{
		System.out.println("Review List clicked");
	}
}
