package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.KPIsPage;

public class KPIsPageTest extends ConfigurePerformancePageTest{

	KPIsPage kPIsPage;
	@BeforeClass
	public void verifyKPIsPageNavigation()
	{
		kPIsPage = configurePerformancePage.navigatingToKPIs();
		Assert.assertTrue(kPIsPage.getcurrentUrl());
		System.out.println("Clicked KPIs and asserted URL");
	}
	
	@Test(priority = 4)
	public void kPIsTesting()
	{
		System.out.println("KPIs clicked");
	}
}
