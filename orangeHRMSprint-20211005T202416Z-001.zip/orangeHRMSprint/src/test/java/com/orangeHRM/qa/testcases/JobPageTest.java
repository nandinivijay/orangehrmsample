package com.orangeHRM.qa.testcases;

import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.JobPage;
import com.orangeHRM.qa.util.ActionsUtil;

public class JobPageTest extends MyInfoPageTest{
	JobPage jobPage;
	WebElement element;

	@BeforeClass
	public void verifyJobPageNavigation() {

		jobPage = myInfoPage.navigatingToJob();
		System.out.println("Clicked Job and url is validated");
	}

	@Test /* (priority=3) */
	public void validateJobButton_bgcolor() {
		try {

			
			// details button bg-color- grey
			element = myInfoPage.getJob_XPath();
			ActionsUtil.MouseHoover(element, driver);
			Assert.assertTrue(myInfoPage.getColor_Sidenav(element).contains(myInfoPage.SIDENAV_CLICKEDCOLOR),
					"*********Buttton clicked color mis match*************");
			System.out.println("Job button bg-color is validated after clicking---grey");
			
			
		} catch (AssertionError ae) {
			System.out.println("In Job Testing--validateJobButton_bgcolor :" + ae.getMessage());
		} catch (WebDriverException we) {
			System.out.println("In Job--validateJobButton_bgcolor :" + we.getMessage());
		}

	}

}
