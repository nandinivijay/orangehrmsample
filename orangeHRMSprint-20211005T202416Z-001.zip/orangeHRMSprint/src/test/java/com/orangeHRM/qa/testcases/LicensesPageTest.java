package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.LicensesPage;

public class LicensesPageTest extends QualificationsPageTest{

	LicensesPage licensesPage;
	@BeforeClass
	public void verifyLicensesPageNavigation()
	{
		licensesPage = qualificationsPage.navigatingToLicenses();
		Assert.assertTrue(licensesPage.getcurrentUrl());
		System.out.println("Clicked Licenses and asserted URL");
	}
	
	@Test(priority = 4)
	public void licensesTesting()
	{
		System.out.println("Licenses clicked");
	}
}
