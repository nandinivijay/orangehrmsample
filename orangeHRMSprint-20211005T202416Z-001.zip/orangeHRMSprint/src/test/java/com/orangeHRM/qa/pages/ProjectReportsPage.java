package com.orangeHRM.qa.pages;

import org.openqa.selenium.WebDriver;

public class ProjectReportsPage {

	WebDriver driver;

	public ProjectReportsPage(WebDriver driver) {
		
		this.driver = driver;
	}
	
	public boolean getcurrentUrl()
	{
		return driver.getCurrentUrl().contains("ProjectReport");
	}

}
