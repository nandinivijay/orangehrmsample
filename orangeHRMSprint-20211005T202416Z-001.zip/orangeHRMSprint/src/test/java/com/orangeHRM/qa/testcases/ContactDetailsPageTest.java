package com.orangeHRM.qa.testcases;

import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.ContactDetailsPage;
import com.orangeHRM.qa.util.ActionsUtil;

public class ContactDetailsPageTest extends MyInfoPageTest {

	ContactDetailsPage contactDetailsPage;
	WebElement element;

	@BeforeClass
	public void verifyContactDetailsPageNavigation() {

		contactDetailsPage = myInfoPage.navigatingToContactDetails();
		System.out.println("Clicked ContactDetailsPage url is validated");
	}

	@Test /* (priority=3) */
	public void validateContactDetailsButton_bgcolor() {
		try {

			// clicking on contact deatils button andthe checking url of page and contact
			 element = myInfoPage.getContactDetails_XPath();
			ActionsUtil.MouseHoover(element, driver);
			Assert.assertTrue(myInfoPage.getColor_Sidenav(element).contains(myInfoPage.SIDENAV_CLICKEDCOLOR));
			System.out.println("Contact Details button bg-color is validated afetr clicking");
		} catch (AssertionError ae) {
			System.out.println("In Contact Details Testing--validateContactDetailsButton_bgcolor :" + ae.getMessage());
		} catch (WebDriverException we) {
			System.out.println("In ContactDetailsPage--validateContactDetailsButton_bgcolor :" + we.getMessage());
		}

	}

}
