package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.ConfigurationTimePage;

public class ConfigurationTimePageTest extends AttendancePageTest{

	ConfigurationTimePage configurationTimePage;
	@BeforeClass
	public void verifyConfigurationTimePageNavigation()
	{
		configurationTimePage = attendancePage.navigatingToConfigurationTime();
		Assert.assertTrue(configurationTimePage.getcurrentUrl());
		System.out.println("Clicked Configuration Time and asserted URL");
	}
	
	@Test(priority = 4)
	public void configurationTimeTesting()
	{
		System.out.println("Configuration Time clicked");
	}
}
