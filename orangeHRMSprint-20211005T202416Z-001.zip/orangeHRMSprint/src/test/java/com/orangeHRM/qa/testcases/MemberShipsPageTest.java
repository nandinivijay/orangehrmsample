package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.MemberShipsPage;

public class MemberShipsPageTest extends QualificationsPageTest{

	MemberShipsPage memberShipsPage;
	@BeforeClass
	public void verifyMemberShipsPageNavigation()
	{
		memberShipsPage = qualificationsPage.navigatingToMemberShips();
		Assert.assertTrue(memberShipsPage.getcurrentUrl());
		System.out.println("Clicked MemberShips and asserted URL");
	}
	
	@Test(priority = 4)
	public void memberShipsTesting()
	{
		System.out.println("MemberShips clicked");
	}
}
