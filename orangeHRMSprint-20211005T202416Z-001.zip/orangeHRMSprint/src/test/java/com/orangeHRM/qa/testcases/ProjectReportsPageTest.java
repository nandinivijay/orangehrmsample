package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.ProjectReportsPage;

public class ProjectReportsPageTest extends ReportsTimePageTest{

	ProjectReportsPage projectReportsPage;
	@BeforeClass
	public void verifyProjectReports()
	{
		projectReportsPage = reportsTimePage.navigatingToProjectReports();
		Assert.assertTrue(projectReportsPage.getcurrentUrl());
		System.out.println("Clicked Project Reports and asserted URL");
	}
	
	@Test(priority = 4)
	public void projectReportsTesting()
	{
		System.out.println("Project Reports clicked");
	}
}
