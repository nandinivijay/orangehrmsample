package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.WorkShiftsPage;

public class WorkShiftsPageTest extends JobAdminPageTest{

	 WorkShiftsPage workShiftsPage;
	@BeforeClass
	public void verifyWorkShiftsPageNavigation()
	{
		workShiftsPage = jobAdminPage.navigatingToWorkShifts();
		Assert.assertTrue(workShiftsPage.getcurrentUrl());
		System.out.println("Clicked  Work Shifts and asserted URL");
	}
	
	@Test(priority = 4)
	public void  workShiftsTesting()
	{
		System.out.println(" Work Shifts clicked");
	}
}
