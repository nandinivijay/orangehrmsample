package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.AccessRecordsPage;


public class AccessRecordsPageTest extends MaintenancePageTest{

	AccessRecordsPage accessRecordsPage;
	@BeforeClass
	public void verifyAccessRecordsPageNavigation()
	{
		accessRecordsPage = maintenancePage.navigatingToAccessRecords();
		Assert.assertTrue(accessRecordsPage.getcurrentUrl());
		System.out.println("Clicked AccessRecords and asserted URL");
	}
	
	@Test(priority = 2)
	public void accessRecordsTesting()
	{
		System.out.println("AccessRecords clicked");
	}
}
