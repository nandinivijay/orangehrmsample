package com.orangeHRM.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.orangeHRM.qa.pages.ModulesPage;


public class ModulesPageTest extends ConfigurationAdminPageTest{

	ModulesPage modulesPage;
	@BeforeClass
	public void verifyModulesPageNavigation()
	{
		modulesPage = configurationAdminPage.navigatingToModules();
		Assert.assertTrue(modulesPage.getcurrentUrl());
		System.out.println("Clicked Modules and asserted URL");
	}
	
	@Test(priority = 4)
	public void modulesTesting()
	{
		System.out.println("Modules clicked");
	}
}
